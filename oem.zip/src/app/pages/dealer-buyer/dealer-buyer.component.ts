import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dealer-buyer',
  templateUrl: './dealer-buyer.component.html',
  styleUrls: ['./dealer-buyer.component.scss'],
})
export class DealerBuyerComponent implements OnInit {

  constructor() { }

  ngOnInit() {}

}
