import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dealers-dashboard',
  templateUrl: './dealers-dashboard.component.html',
  styleUrls: ['./dealers-dashboard.component.scss'],
})
export class DealersDashboardComponent implements OnInit {

  constructor() { }

  ngOnInit() {}

}
