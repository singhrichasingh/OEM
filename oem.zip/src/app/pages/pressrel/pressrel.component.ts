import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pressrel',
  templateUrl: './pressrel.component.html',
  styleUrls: ['./pressrel.component.scss'],
})
export class PressrelComponent implements OnInit {

  constructor() { }

  ngOnInit() {}

}
