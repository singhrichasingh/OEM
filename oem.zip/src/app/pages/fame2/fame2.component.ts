import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-fame2',
  templateUrl: './fame2.component.html',
  styleUrls: ['./fame2.component.scss'],
})
export class Fame2Component implements OnInit {

  constructor() { }

  ngOnInit() {}

}
