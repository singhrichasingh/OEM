import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-imp-link',
  templateUrl: './imp-link.component.html',
  styleUrls: ['./imp-link.component.scss'],
})
export class ImpLinkComponent implements OnInit {

  constructor() { }

  ngOnInit() {}

}
